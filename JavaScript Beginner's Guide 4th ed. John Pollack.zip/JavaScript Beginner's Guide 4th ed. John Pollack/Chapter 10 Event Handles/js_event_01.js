function hi_and_bye() {
	window.alert('Hi');
	window.alert('Bye');
}