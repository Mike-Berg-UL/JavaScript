
var headingText = "<h1>A Page of JavaScript</h1>";
var myIntro  = "Hello, welcome to my Javascript Page!";
var linkTag = "<a href=\"http://cnn.com\">Link to CNN</a>";
var redText = "<span style=\"color: red\">I am so colorful today!</span>";
var beginEffect = "<em>";
var endEffect = "</em>";
var beginPara = "<p>";
var endPara = "</p>";

document.write(headingText);
document.write(beginEffect + myIntro + endEffect);
document.write(beginPara + linkTag + endPara);
document.write(beginPara + redText + endPara);