var myHeading = "<h1>This is My Web Page!</h1>",
linkTag = "<a href=\"http://www.cnn.com\">Link to CNN!</a>",
someText = "This text can be affected by other statements.",
beginEffect = "<strong>",
endEffect = "</strong>",
beginPara = "<p>",
endPara = "</p>";
document.write(myHeading);
document.write(beginEffect + someText + endEffect);
document.write(beginPara + linkTag + endPara);
document.write(beginPara + someText + endPara);