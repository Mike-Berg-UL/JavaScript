var getphone = document.getElementById("getphone");
getphone.addEventListener("submit", function(event) {
	var phone = document.getElementById("phone").value,
		tomatch = /^\d{3}-\d{3}-\d{4}$/;
	event.preventDefault();
	if (!tomatch.test(phone)) {
		alert("Invalid phone number entered. Valid format is XXX-XXXX.");
	}
}, false);