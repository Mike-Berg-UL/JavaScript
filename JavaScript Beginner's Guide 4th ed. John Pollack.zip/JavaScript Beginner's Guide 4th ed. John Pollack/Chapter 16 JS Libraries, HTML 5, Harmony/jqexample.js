$(document).ready(function() {
	$("#story").click(function() {
		if (!$("#story").hasClass("style3")) {
			$("#story").addClass("style3");
		}
	});
});