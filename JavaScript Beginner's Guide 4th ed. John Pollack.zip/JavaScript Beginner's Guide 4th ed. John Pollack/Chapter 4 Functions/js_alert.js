
function show_message() {
window.alert("Alert!!!! Mike is the coolest!!!!");
}
window.alert("I am first, ha!");
window.alert("I am second, ha!");
show_message();