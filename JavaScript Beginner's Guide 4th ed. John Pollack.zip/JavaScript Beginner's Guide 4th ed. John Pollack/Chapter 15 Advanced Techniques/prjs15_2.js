var slink = document.getElementById("slink");
slink.addEventListener("click", function() {
	event.preventDefault();
	window.open('sales.html', 'newwin', 'width=300,height=200');
}, false);