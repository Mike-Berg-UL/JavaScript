var computer_parts = ["Monitors", "Motherboards", "Chips", "Hard Drives", "DVD-ROMS", 
	"Cases", "Power Supplies"];
for ( var i = 0; i < computer_parts.length; i++) {
	document.write(computer_parts[i] + "<br>");
}